//
//  MFApi.h
//  Pods-SDK_MF_ios_Example
//
//  Created by 张亮 on 2019/11/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MFBuilder : NSObject

///** 服务器响应，是否压缩数据，默认进行压缩. 1 是 0 否 */
@property (assign, nonatomic) NSInteger gzip;

/** 客户端包名 */
@property (strong, nonatomic) NSString *pkgname;

/** 业务id，多个用逗号分隔 */
@property (strong, nonatomic) NSString *sid;

/** 产品id */
@property (assign, nonatomic) NSInteger cid;

/** 客户端版本号，必须大于0 */
@property (strong, nonatomic) NSString *cversion;

/** 国家（统一传大写）*/
@property (strong, nonatomic) NSString *local;

/** GA参数买量渠道名，空为自然渠道 */
@property (strong, nonatomic) NSString *utm_source;

/** 业务请求入口，必须大于0 */
@property (assign, nonatomic) NSInteger entrance;

/** 客户端安装天数，必须大于0，刚安装传1 */
@property (assign, nonatomic) NSInteger cdays;

/** 是否升级用户 1. 是 2. 不是。不传或者非法传递则认为是升级用户 */
@property (assign, nonatomic) NSInteger isupgrade;

/** 客户端安卓ID */
@property (strong, nonatomic) NSString *aid;

/** 用户来源类型 */
@property (strong, nonatomic) NSString *user_from;

/** sid的数组 */
@property (copy  , nonatomic) NSArray *sids;

/**  IOS操作系统版本号 可以为空 */
@property (nonatomic, copy) NSString *system_version_name;

/** 是否使用缓存数据 */
@property (nonatomic, assign) BOOL cache;

@end

/**
 业务请求入口

 - MFEntranceMainPackage: 主包
 - MFEntranceTheme: 主题
 - MFEntranceTest: 测试
 */
typedef NS_ENUM(NSUInteger, MFEntrance) {
    MFEntranceMainPackage = 1,
    MFEntranceTheme = 2,
    MFEntranceTest = 999,
};

#pragma mark - 请求回调block
typedef void(^ABRequestCompletionBlock)(NSDictionary * _Nullable dict, NSError * _Nullable error);


#pragma mark - 对外公开api
@interface MFApi : NSObject

/** 是否输出log */
+ (void) setEnableLog:(BOOL) enable;

/** 内部使用的log输出 */
+ (void) logD:(NSString *) logMsg;

/** 在 调用createApiWithBuilder 前调用，初始化mfsdk 抛弃通过plist配置方式初始化*/
+ (void) initWithProdkey:(NSString *)prodkey accessKey:(NSString *) accessKey des:(NSString *) desKey host:(NSString *) host;

/** 创建api 实例 */
+ (instancetype)createApiWithBuilder:(void(^)(MFBuilder * builder))builder;

/** 发起真是请求，请求的数据会缓存， 如果使用缓存数据请设置cache = true */
- (void)requestWithCompletion:(ABRequestCompletionBlock)completion;

@end

NS_ASSUME_NONNULL_END
